/** @file Cjt_Huecos.cc
    @brief Representa el conjunt de forats del Àrea de almacenaje.
*/

#include "Cjt_Huecos.hh"

//una lista con todas las ubicaciones de los huecos, ir borrandolas a medida que metamos contenedores
//inicialmente con todo huecos en el piso 0, luego añadir encima de un contenedor y crear cuando se retire un contenedor
Cjt_Huecos::Cjt_Huecos() {} 

Cjt_Huecos::~Cjt_Huecos() {}

void Cjt_Huecos::agregar_hueco(Segmento& s) 
{ 
    //al inicio en el piso 0, en el piso de encima cuando se añada un contenedor y cuando se retire uno
    huec.insert(s);
}

void Cjt_Huecos::eliminar_hueco(Segmento& s) 
{ 
    //al añadirse un contenedor
    huec.erase(s);  
}

Ubicacion Cjt_Huecos::ubi_buena(int l) 
{
    //ubi ideal para colocar un contenedor en la matriz
    for (set<Segmento>::const_iterator it = huec.begin(); it != huec.end(); ++it) {
        if (l <= it->longitud()){
            Segmento s = (*it);
            huec.erase(it); //eliminamos hueco
            return s.ubic();
        }
    }
    return Ubicacion(-1,0,0);
}

void Cjt_Huecos::imprimir() const 
{
    //ordenar por tamaño, y si no, por hilera y plaza
    for (set<Segmento>::const_iterator it = huec.begin(); it != huec.end(); ++it) {
        if (it->longitud() != 0) { it->print(); 
        cout << endl;
        }
    }
    cout << endl;
}