/** @file Cjt_Huecos.hh
    @brief Especificació de la classe Cjt_Huecos.
*/

#ifndef _CJT_HUECOS
#define _CJT_HUECOS

#ifndef NO_DIAGRAM
#include <iostream>
#include <set>
#include <algorithm>
#endif

#include "Segmento.hh"

/** @class Cjt_Huecos
    @brief Representa el conjunt de forats del Àrea de almacenaje.
*/

class Cjt_Huecos
{

public:
    
//Constructores

/** @brief Creadora sense arguments
    \pre <em>Cert</em>
    \post El resultat és un conjunt de forats buit.
*/

Cjt_Huecos();

//Destructora

/** @brief Destructora
    \pre <em>Cert</em>
    \post Destrueix un objecte Cjt_Huecos.
*/

~Cjt_Huecos();

//Consultores

/** @brief Consultora de la ubicació òptima per col·locar un contenidor
    \pre El conjunt no està buit
    \post Retorna el millor forat per col·locar un contendidor segons l'estratègia BEST_FIT.
*/
    
Ubicacion ubi_buena(int l);

//Modificadores
   
/** @brief Afegidora d'un forat al conjunt
    \pre El forat no existia prèviament al conjunt. El conjunt no està ple.
    \post Afegeix un forat al conjunt.
*/

void agregar_hueco(Segmento& s);

/** @brief Eliminadora d'un forat del conjunt
    \pre El forat hi és al conjunt. El conjunt no està buit.
    \post Elimina un forat del conjunt.
*/

void eliminar_hueco(Segmento& s);

//Entrada/sortida

/** @brief Impressió dels forats
    \pre <em>Cert</em>
    \post Imprimeix els forats de l'Àrea d'almacenaje, ordenats per longitud i Ubicació
*/

void imprimir() const;

private:

/** 
    @brief Un conjunt de segments que representen els espais vàlids de la matriu, ordenats per longitud, i a continuació per filera i plaça
*/
set<Segmento> huec;
};

#endif