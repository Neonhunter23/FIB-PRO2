/** @file Terminal.cc
    @brief Representa una terminal composada d'una àrea de espera i una àrea d'emmagatzemament.
*/

#include "Terminal.hh"

Terminal::Terminal(){}

Terminal::Terminal(int N, int M, int H) 
{
    //Constructoras de todas las clases
    holes = Cjt_Huecos();
    a = Area_almacenaje(N, M, H);
    for (int i = 0; i < N; ++i) {
        //piso de abajo todo huecos
        Segmento s = Segmento(Ubicacion(i, 0, 0), M);
        holes.agregar_hueco(s);
    }
    b = Area_espera();
    d = Cjt_Contenedores();
    
}

Terminal::~Terminal(){}

void Terminal::insertar_contenedor(Contenedor& c) 
{
    Segmento s(holes.ubi_buena(c.longitud()),c.longitud());
    Ubicacion u = s.ubic();
    Ubicacion al_area(-1,0,0); //para saber si va a la terminal o al area de espera
    u.print();
    d.afegir_cont(c.matricula(), s);
    //si la terminal esta llena o el hueco es pequeño, al area que se va
    if (u == al_area) {
        b.insertar_contenedor_area(c);
    }
    else {
        a.insertar(c, u, holes);
        //comprueba si se pueden meter contenedores del area de espera
        if (not b.esta_vacia()) insertar_espera();
    }
    cout << endl;
   
}

void Terminal::retirar_contenedor(const string& m) 
{
    //al retirar un contenedor que tenga otros encima, esos se van al area de espera
    Segmento s = d.obten_contenedor(m);
    Ubicacion u(-1,0,0);
    //caso de que queramos retirar un contenedor que este en el area de espera
    d.retirar_cont(m);
    if (s.ubic() == u) {
        b.retirar_contenedor_area(m);
    }
    else {
    //sacar contenedores de encima, cambiar ubi y meterlos en el area de espera   
    //lo retiramos de la matriz
    a.retirar(s,holes,d, b);
    if (not b.esta_vacia()) insertar_espera(); //comprobar si se pueden volver a meter los contenedores del area de espera 
    }
}

void Terminal::insertar_espera() 
{ 
    //recorrer toda la lista para ver si puedo meter los contenedores
    int y = 0;
    bool x = true;
    pair<Contenedor,char> n;
    while (n.second != '.') {
        n = b.consultar_sacar(y,x);
    Ubicacion bue = holes.ubi_buena(n.first.longitud());
        if (bue != Ubicacion(-1,0,0)) {
        //es posible insertar un contenedor de la lista?
        a.insertar(n.first,bue,holes);
        x = true;
        y = 0;
        Segmento s(bue,n.first.longitud());
        d.mod_ubi(n.first.matricula(),s); //cambiar la ubi a la ideal para la matriz
        b.retirar_contenedor_area(n.first.matricula()); //eliminamos el que quiero retirar
     }
        else {
        ++y;
        x = false;
        }
    }
}

bool Terminal::existe_contenedor(string& m) const 
{
    return d.existe(m);
}

void Terminal::posicion_contenedor(string& m)const 
{
    Segmento c = d.obten_contenedor(m); 
    c.ubic().print();
    cout << endl;
}

int Terminal::longi_contenedor(string& m) const 
{
    Segmento x = d.obten_contenedor(m);
    return x.longitud();
}

string Terminal::contenedor_ocupa(int i, int j, int k) const 
{
   return a.ocupa(i,j,k);
}

int Terminal::filas_al() const 
{
    return a.filas();
}

int Terminal::plazas_al() const 
{
    return a.plazas();
}

int Terminal::pisos_al() const 
{
    return a.pisos();
}

void Terminal::imprimir_area_espera() const 
{
    b.imprimir();
}

void Terminal::imprimir_contenedores() const 
{
    d.imprimir();
}

void Terminal::imprimir_area_almacenaje() const 
{
    a.imprimir();
}

void Terminal::imprimir_huecos() const
{
    holes.imprimir();
}

