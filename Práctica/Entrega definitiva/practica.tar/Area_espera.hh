/** @file Area_espera.hh
    @brief Especificació de la classe Area_espera.
*/

#ifndef _AREA_ESPERA
#define _AREA_ESPERA

#ifndef NO_DIAGRAM
#include <list>
#include <iostream>
#endif

#include "Contenedor.hh"
using namespace std;

/** @class Area_espera
    @brief Representa una àrea d'espera on guardarem els contenidors a recol·locar de l'àrea d'almacenaje
*/

class Area_espera
{

public:

//Constructores

/** @brief Creadora sense arguments
    \pre <em>Cert</em>
    \post El resultat és una Area de espera buida.
*/

Area_espera();

//Destructora

/** @brief Destructora
    \pre <em>Cert</em>
    \post Destrueix un objecte Area_espera.
*/

~Area_espera();

//Consultores

/** @brief Consultora d'extracció de contenidors de l'àrea d'espera
    \pre <em>Cert</em>
    \post Retorna els contenidors que es poden recol·locar a la matriu després de retirar-ne un.
*/

pair<Contenedor,char> consultar_sacar(int pos_espera,bool b) const;

/** @brief Consultora de llista buida
    \pre <em>Cert</em>
    \post Retorna cert el paràmetre implícit està buit. Fals en cas contrari.
*/

bool esta_vacia();

//Modificadores

/** @brief Insertar contenidor a l'Àrea d'espera
    \pre El contenidor té una ubicació vàlida a l'Area de almacenaje
    \post S'ha insertat un contenidor a l'area d'espera i la seva ubiació ha canviat a -1,0,0.
*/
    
void insertar_contenedor_area(Contenedor& c);

/** @brief Retirar contenidor de l'Àrea d'espera
    \pre L'Àrea d'espera no és buida. El contenidor hi és a l'Àrea d'espera
    \post S'ha retirat el contenidor de l'Àrea d'espera.
*/

void retirar_contenedor_area(const string& m);

//Entrada/sortida

/** @brief Escriptura de l'àrea d'espera
    \pre <em>Cert</em>
    \post El resultat és el contingut de l'àrea d'espera, ordenada pels contenidors més nous primer.
*/

void imprimir() const; //llamado desde terminal

private:

/**
    @brief Llista dels contenidors enviats a l'àrea d'espera, ordenada per entrada
*/
    list<Contenedor> esp;
};

#endif