/** @file Cjt_Contenedores.hh
    @brief Especificació de la classe Cjt_Contenedores.
*/

#ifndef _CJT_CONTENEDORES
#define _CJT_CONTENEDORES

#ifndef NO_DIAGRAM
#include <map>
#include <iostream>
#include <string>
#endif

#include "Contenedor.hh"
#include "Segmento.hh"
using namespace std;

/** @class Cjt_Contenedores
    @brief Representa el conjunt de contenidors a l'Àrea d'almacenaje
*/

class Cjt_Contenedores
{

public:

//Constructores

/** @brief Creadora sense arguments
    \pre <em>Cert</em>
    \post El resultat es un conjunt de contenidors buit.
*/
   
Cjt_Contenedores();

//Destructora

/** @brief Destructora
    \pre <em>Cert</em>
    \post Destrueix un objecte Cjt_Contenedores.
*/

~Cjt_Contenedores();

//Consultores

/** @brief Consultora d'existència
    \pre <em>m</em> és una matrícula vàlida
    \post Retorna <em>Cert</em> si el contenidor amb matrícula <em>m</em> existeix al conjunt.
*/

bool existe(string m) const; //buscar en el map

/** @brief Consultora d'un contenidor del conjunt
    \pre <em>m</em> és una matrícula vàlida.
    \post Retorna el contenidor del conjunt amb matrícula <em>m</em>.
*/

Segmento obten_contenedor(const string& m) const;

//Modificadores

/** @brief Afegir contenidor al conjunt
    \pre Al conjunt no hi havia un contenidor amb matrícula <em>m</em>. El conjunt no está ple
    \post S'ha afegit un contenidor al conjunt.
*/

void afegir_cont(const string& a, Segmento s);

/** @brief Retirar contenidor del conjunt
    \pre El contenidor amb matrícula <em>m</em> vàlida hi era al conjunt. El conjunt no está buit
    \post S'ha retirat un contenidor del conjunt.
*/

void retirar_cont(string m);

/** @brief Modificadora de la Ubicació d'un contendor
    \pre El contenidor tenia una ubicació vàlida dins de l'àrea d'almacenaje
    \post S'ha modificat la Ubicació del contenidor per què accedeixi a l'àrea d'espera.
*/

void cambiar_ubi(Contenedor& c);

/** @brief Modificadora de la ubicació d'un contenidor de l'àrea d'espera
    \pre El contenidor estava a l'àrea d'espera. Hi ha un forat apte per que pugui ser inserit de nou
    \post Canvia la ubicació d'un contenidor de l'àrea d'espera a una ubicació de la matriu.
*/

void mod_ubi(const string& m, Segmento& s);

//Entrada/sortida

/** @brief Impressió del conjunt de contenidors
    \pre El conjunt no està buit
    \post Imprimeix el conjunt de conenidors de l'Àrea d'almacenaje, ordenats per matrícula.
*/

void imprimir() const; //llamado desde terminal

private:

/**
    @brief Diccionari dels contenidors que hi ha a la terminal, ordenats per matrícula
*/
    map<string,Segmento> mapa;
};

#endif