/** @file Cjt_Contenedores.cc
    @brief Representa el conjunt de contenidors a l'Àrea d'almacenaje.
*/

#include "Cjt_Contenedores.hh"

Cjt_Contenedores::Cjt_Contenedores() {}

Cjt_Contenedores::~Cjt_Contenedores() {}

Segmento Cjt_Contenedores::obten_contenedor(const string& m) const 
{
    //buscamos en el map si el contenedor esta, y tenemos que devolver su ubicacion
    //al buscar en el map, guardar el second
    map<string,Segmento>::const_iterator it = mapa.find(m);
    if (it != mapa.end()) {
        return it->second;
    }
    return Segmento();
}

bool Cjt_Contenedores::existe(string m) const 
{
    //está en el map?
    return (mapa.find(m) != mapa.end());
}
     
void Cjt_Contenedores::afegir_cont(const string& a, Segmento s) 
{
    mapa.insert(make_pair(a,s)); //en el segmento ya esta la ubi de la matriz
}

void Cjt_Contenedores::retirar_cont(string m) 
{
    //quitamos un contenedor del map
    map<string,Segmento>::iterator it = mapa.find(m);
    mapa.erase(it);
}

void Cjt_Contenedores::cambiar_ubi(Contenedor& c) 
{
    //cambiamos las coord de un contenedor de la matriz para que vaya al area de espera
    Ubicacion u(-1,0,0);
    Segmento s(u,c.longitud());
    mapa[c.matricula()] = s;
}

void Cjt_Contenedores::mod_ubi(const string& m,Segmento& s) 
{
    //cambio la ubi del area de espera a la de la matriz
    mapa[m] = s;
}

void Cjt_Contenedores::imprimir() const {
    //nombre (first), ubicacion y long (second)
    for (map<string,Segmento>::const_iterator it = mapa.begin(); it != mapa.end(); ++it) {
        cout << it->first;
        if (it->second.longitud() != 0) {
        it->second.print();
        cout << endl;
        }
    }
    cout << endl;
}

