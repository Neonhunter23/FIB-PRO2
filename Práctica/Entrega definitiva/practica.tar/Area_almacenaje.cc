/** @file Area_almacenaje.cc
    @brief Representa una àrea d'almacenaje de contenidors amb tres paràmetres que indicaran les seves dimensions.
*/

#include "Area_almacenaje.hh"

Area_almacenaje::Area_almacenaje()
{
    area = vector<hilera>();
}

Area_almacenaje::Area_almacenaje(int a, int b, int c)
{
    //crear la matriz 3D con estos valores
    //inicializar el piso 0 con todo huecos, y el resto de pisos con espacios invalido
    //inicialmente los huecos del piso 0 de cada hilera tienen long M
    Cjt_Huecos huec;
    Segmento s;
    N = a;
    M = b;
    H = c;

    area = vector<hilera>(N);

    //inicializar la matriz con todo huecos en el piso 0

    for (int i = 0; i < N; ++i)
    {
        hilera h(H, piso(M));
        for (int j = 0; j < H; ++j)
        {
            for (int k = 0; k < M; ++k)
            {
                if (j == H - 1)
                {                  
                    h[j][k].n = 1; //todo huecos
                }
                else
                    h[j][k].n = -1; //las filas de arriba son espacios libres
                Contenedor c;
                h[j][k].cont = c; //toda la fila de abajo vacia
            }
        }
        area[i] = h;
    }
}

Area_almacenaje::~Area_almacenaje() {}

void Area_almacenaje::actualizar_huecos_ins(Ubicacion& u, int l, Cjt_Huecos &huec)
{
    int der = 0; //solo mirar derecha
    //mirar piso y superior, si hay un 1 es hueco, mirar el de la derecha
    int a = u.plaza() + l; //plaza a la derecha de u
    while (a < M)
    {
        if (area[u.hilera()][H-1-u.piso()][a].n == 1)
        { //hay un hueco a la derecha de u
            ++der;
            ++a;
        }

        else
        {
            a = M;
        }  
    }
    if (der > 0)
        {
            Ubicacion v(u.hilera(), u.plaza() + l, u.piso());
            Segmento t(v, der);
            huec.agregar_hueco(t);
        }
    if (u.piso() < H-1) {
        a = u.plaza() + l;
        int b = u.plaza() - 1;
        int izq = 0, der = 0;
        while (a < M)
        {
            if (area[u.hilera()][H-u.piso()-2][a].n == 1)
            {
                ++der;
                ++a;
            }
            else
            {
                a = M;
            }
        }
        while (b >= 0)
        {
            if (area[u.hilera()][H-u.piso()-2][b].n == 1)
            {
                ++izq;
                --b;
            }
            else
            {
                b = -1;
            }
        }
        Ubicacion w(u.hilera(), u.plaza() - izq, u.piso() + 1); //el de arriba
        if (izq > 0)
        {
            Segmento f(w, izq);
            huec.eliminar_hueco(f);
        }

        if (der > 0)
        {
            Ubicacion v(u.hilera(), u.plaza() + l, u.piso() + 1);
            Segmento b(v, der);
            huec.eliminar_hueco(b);
        }
        Segmento f(w, izq + l + der);
        huec.agregar_hueco(f);
    }   
}

void Area_almacenaje::actualizar_huecos_ret(Ubicacion u, int l, Cjt_Huecos &huec)
{
    int izq = 0, der = 0;
    int a = u.plaza() + l;
    int b = u.plaza() - 1;
    while (a < M)
    {
        if (area[u.hilera()][H-1-u.piso()][a].n == 1)
        {
            ++der;
            ++a;
        }

        else
        {
            a = M;
        }
    }
    while (b >= 0)
    {
        if (area[u.hilera()][H-1-u.piso()][b].n == 1)
        {
            ++izq;
            --b;
        }
        else
        {
            b = -1;
        }
    }
    Ubicacion w(u.hilera(), u.plaza() - izq, u.piso());
    if (izq > 0)
    {
        Segmento f(w, izq);
        huec.eliminar_hueco(f);
    }

    if (der > 0)
    {
        Ubicacion v(u.hilera(), u.plaza() + l, u.piso());
        Segmento b(v, der);
        huec.eliminar_hueco(b);
    }
    Segmento e(w, izq + l + der);
    huec.agregar_hueco(e);

    if (u.piso() < H - 1)
    {
        a = u.plaza() + l;
        b = u.plaza() - 1;
        izq = 0, der = 0;
        while (a < M)
        {
            if (area[u.hilera()][H-u.piso()-2][a].n == 1)
            {
                ++der;
                ++a;
            }

            else
            {
                a = M;
            }
        }
        while (b >= 0)
        {
            if (area[u.hilera()][H-u.piso()-2][b].n == 1)
            {
                ++izq;
                --b;
            }
            else
            {
                b = -1;
            }
        }
        Ubicacion w(u.hilera(), u.plaza() - izq, u.piso() + 1); //el de arriba
        if (izq > 0)
        {
            Segmento f(w, izq);
            huec.agregar_hueco(f);
        }

        if (der > 0)
        {
            Ubicacion v(u.hilera(), u.plaza() + l, u.piso() + 1);
            Segmento b(v, der);
            huec.agregar_hueco(b);
        }
        Segmento f(w, izq + l + der);
        huec.eliminar_hueco(f);
    }
}

void Area_almacenaje::insertar(Contenedor& c, Ubicacion &u, Cjt_Huecos &huec)
{
    for (int i = 0; i < c.longitud(); ++i)
    {
        area[u.hilera()][H-u.piso()-1][u.plaza() + i].cont = c;
        area[u.hilera()][H-u.piso()-1][u.plaza() + i].n = 0; //ahora es contenedor
        if (u.piso() < H - 1) area[u.hilera()][H-u.piso()-2][u.plaza() + i].n = 1; //el piso de arriba es hueco
    }
    actualizar_huecos_ins(u, c.longitud(), huec); 
}

void Area_almacenaje::retirar(Segmento s, Cjt_Huecos &huec, Cjt_Contenedores& d, Area_espera& b)
{
    Ubicacion u = s.ubic(); //tengo las coordenadas del contenedor que quiero retirar
    Contenedor c;
    int x = s.longitud();
    //cambiar el contenido de las casillas que ocupe
    if (u.piso() < H-1) cont_encima(area[u.hilera()][H-u.piso()-1][u.plaza()].cont, s, huec, d, b); //comprobamos que tiene conts encima
    for (int i = 0; i < x; ++i)
    {
        area[u.hilera()][H-u.piso()-1][u.plaza() + i].cont = c;
        area[u.hilera()][H-u.piso()-1][u.plaza() + i].n = 1; //hay hueco
        if (u.piso() < H - 1)
           area[u.hilera()][H-u.piso()-2][u.plaza() + i].n = -1; //el piso de arriba pasa a ser espacio invalido
    }
    actualizar_huecos_ret(u, x, huec);
}

string Area_almacenaje::ocupa(int i, int j, int k) const
{
    //dadas unas coordenadas, buscar qué contenedor hay alli
    if (area[i][H-1-k][j].n == 0)
        return area[i][H-1-k][j].cont.matricula();
    else return ""; //devuelve nada si la ubicacion esta vacia
}

void Area_almacenaje::cont_encima(Contenedor& t, Segmento& s, Cjt_Huecos& huec, Cjt_Contenedores& d, Area_espera& b) 
{
    Contenedor c;
    Ubicacion u = s.ubic();
    int x = s.longitud();
    //LA FUNCION RECURSIVA, BUSCA SI UN CONTENEDOR QUE QUEREMOS RETIRAR TIENE CONTENEDORES ENCIMA
   
    if (u.piso() < H-1) { //caso recursivo
         for (int i = 0; i < x; ++i) {
            if(area[u.hilera()][H-u.piso()-2][u.plaza()+i].n == 0) {
                Segmento k = d.obten_contenedor(area[u.hilera()][H-u.piso()-2][u.plaza()+i].cont.matricula());
                cont_encima(t, k, huec, d, b);
            } 
        }
    }
    //caso base: contenedor en el ultmo piso o sin contenedores encima
    if (t != area[u.hilera()][H-u.piso()-1][u.plaza()].cont) { //asi no muevo el que quiero retirar al area de espera
    for (int i = 0; i < x; ++i)
        {
        //guardar el nombre y la longitud de los contenedores que saquemos, cambiarles la ubi y meterlos en el area de espera

        d.cambiar_ubi(area[u.hilera()][H-u.piso()-1][u.plaza() + i].cont); //cambiar solo una vez
        b.insertar_contenedor_area(area[u.hilera()][H-u.piso()-1][u.plaza() + i].cont); //mal

        area[u.hilera()][H-u.piso()-1][u.plaza() + i].cont = c;
        area[u.hilera()][H-u.piso()-1][u.plaza() + i].n = 1; 
        if (u.piso() < H - 1)
           area[u.hilera()][H-u.piso()-2][u.plaza() + i].n = -1; 
        }
    }
    //con esto, saco todos los contenedores de encima y el de abajo no lo elimino, pero puedo hacer pop back del primero y ya
    actualizar_huecos_ret(u, x, huec);
}

int Area_almacenaje::filas() const
{
    return N;
}

int Area_almacenaje::plazas() const
{
    return M;
}

int Area_almacenaje::pisos() const
{
    return H;
}

void Area_almacenaje::imprimir() const
{
    //doble for 
    //se imprime la primera letra del contenedor en cada casilla
    //primero el numero de piso, luego la inicial de los contenedores
    //cuando los pisos lleguen a 0 y se hayan escrito los contenedores, luego hacemos una fila de numeros que marquen las plazas
    for (int i = 0; i < N; ++i)
    {
        hilera h = area[i];
        cout << "hilera " << i << endl;
        for (int k = 0; k < H; ++k)
        {
            for (int j = 0; j < M; ++j)
            {
                if (j == 0)
                {
                    cout << H - 1 - k << " ";
                }
                if (h[k][j].n == 0) {
                    cout << h[k][j].cont.matricula()[0]; //primera letra del contenedor
                }
                else cout << " ";
            }
            cout << endl;
        }
        for (int i = 0; i < M; ++i)
        {
            if (i == 0)
                cout << "  " << i;
            else if (i > 9)
                cout << i % 10; //si hay mas de 10 plazas
            else
                cout << i;
        }
        cout << endl << endl;
    }
}