/** @file Area_espera.cc
    @brief Representa una àrea d'espera on estarán els contenidors que no estiguin a l'àrea d'almacenaje.
*/
#include "Area_espera.hh"

Area_espera::Area_espera() {}

Area_espera::~Area_espera() {}

//lista a modo de pila
void Area_espera::insertar_contenedor_area(Contenedor& c)
{
    //mete los contenedores de la matriz en el area de espera
    if (esp.empty()) esp.push_back(c);
    else {
        if ((*esp.begin()) != c) esp.push_front(c);
        //eliminar duplicados
    }
}

pair<Contenedor, char> Area_espera::consultar_sacar(int pos_espera,bool b) const 
{ 
    pair<Contenedor,char> de;
    Contenedor c;
    de.first = c;
    de.second = 'p';
    int i = 0;

    if (b) { //empezar por el primer elemento
        list<Contenedor>::const_iterator it = esp.begin();
        de.first = (*it);
        ++it;
        if (it == esp.end()) de.second = '.';
        return de;
    }

    for (list<Contenedor>::const_iterator it = esp.begin(); it != esp.end(); ++it) {
        //revisar toda la lista para ver si los contenedores se pueden meter
        if (i == pos_espera) {
            de.first = (*it);
            return de;
        }
        else ++i;
    }
    de.second = '.';
    return de;
}

bool Area_espera::esta_vacia() 
{
    //esta vacia?
    return esp.empty();
}

void Area_espera::retirar_contenedor_area(const string& m) 
{
    //saca un contenedor del area
    for (list<Contenedor>::iterator it = esp.begin(); it != esp.end(); ++it) {
        if ((*it).matricula() == m) {
        esp.erase(it);
        return;
        }
    }
}

void Area_espera::imprimir() const 
{
    //imprime los contenedores del area
    for (list<Contenedor>::const_iterator it = esp.begin(); it != esp.end(); ++it) {
        (*it).print();
        cout << endl;
    }
    cout << endl;
}
    
