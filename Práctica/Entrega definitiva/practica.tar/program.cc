/** 
    \file program.cc
    \brief archivo base del programa
*/

#include "Terminal.hh"

#ifndef NO_DIAGRAM
#include <iostream>
#include <string>
#endif
using namespace std;
//main del programa principal
/** @mainpage Documentació de la pràctica: Gestió d'una terminal de contenidors
    @brief Aquesta és la pàgina principal de la documentació de la pràctica.
    @brief Els objectius principals de la pràctica eren:
    \arg Crear una implementació de l'enunciat de forma adequada.
    \arg Aprendre a documentar correctament un projecte de programació.
    \arg Aprendre a escriure un codi poc costós, eficient i modular.

    \section versio1 v0.0 del 20-10-2020:
    @brief després de descarregar-me l'enunciat de la pràctica, me'l vaig llegir sencer apuntant les dades més importants.
    \arg pensades quines classes hauré de crear per la pràctica: Terminal, Area_almacenaje, Area_espera, Cjt_Contenedores.
    \arg el primer que creo es el main, amb tots els casos possibles de comandes i les corresponents crides a la classe Terminal.
    \arg un cop creat el main, creo la classe Terminal i especifico les funcions al .hh
    \arg els següents dies creo el conjunt de contendors, l'àrea d'almacenaje i el conjunt de forats.
    \arg finalment creo el Doxyfile i l'entrego pel Racó.

    \section versio2  v0.9 del 20-11-2020, entrega intermitja:
    \arg totes les classes han sigut creades, s'han implementat les funcions necessàries per cumplir tots els jocs de proves correctament.
    \arg Resultat de 4/4 en l'entrega intermitja al Jutge.
    \arg especifico la classe Area_espera per a la propera entrega.

    \section versio3  v1.0 del 30-11-2020, entrega final provisional:
    \arg implementada la classe Area_espera, afegides funcions tant a Area_almacenaje com al Cjt_Contenedores per poder adaptar-se a les noves normes dels jocs de proves.
    \arg retoc general de la pràctica: millores d'eficiència, funcions auxiliars per no repetir càlculs innecessaris.
    \arg Resultat de 4/4 al Jutge.

    \section versio4 v1.def del 1-12-2020, entrega final definitiva:
    \arg corregides les Pre/Post de totes les funcions de totes les classes.
    \arg Resultat de 4/4 al Jutge. Molta felicitat i satisfacció.

*/

int main()
{
    //Obtenir la comanda
    string comando = "";
    cin >> comando;

    while (comando != "fin")
    {
        string m;    //matricula de un contenedor
        int l;       //longitud de un contenedor
        int N = 0, M = 0, H = 0; //hileras, pisos del segmento, plazas
        Contenedor c;
        //crear terminal done
        cin >> N >> M >> H;
        cout << "#crea_terminal " << N << " " << M << " " << H << endl;
        
        Terminal t(N, M, H);
        cin >> comando;
        while (comando != "fin" and comando != "crea_terminal")
        {
            if (comando == "inserta_contenedor" or comando == "i") 
            {
                cin >> m >> l; 
                if (comando == "inserta_contenedor")
                    cout << "#inserta_contenedor" << " " << m << " " << l << endl;
                else cout << "#i" << " " << m << " " << l << endl;

                c = Contenedor(m, l);
                if (t.existe_contenedor(m)) 
                {
                    cout << "error: el contenedor ya existe" << endl;
                }
                else
                {
                    t.insertar_contenedor(c); //hará cout de la primera posicion ocupada   
                }
            }

            else if (comando == "retira_contenedor" or comando == "r")
            {
                cin >> m; //retira contenedor del map excepto que no este

                if (comando == "retira_contenedor")
                    cout << "#retira_contenedor" << " " << m << endl;
                else cout << "#r" << " " << m << endl;

                if (t.existe_contenedor(m))
                {
                    t.retirar_contenedor(m);
                }
                else cout << "error: el contenedor no existe" << endl;
            }

            else if (comando == "donde") 
            {
                cin >> m; //busca el contenedor en el map
                //area de almacenaje: ubicacion con menor M
                //area espera: -1,0,0
                //no existe: -1,-1,-1

                cout << "#donde " << m << endl;
                if (t.existe_contenedor(m))
                {
                    t.posicion_contenedor(m); //buscar en el map, devolvera ubicacion
                }
                else cout << "<-1,-1,-1>" << endl;
            }

            else if (comando == "longitud") 
            {
                cin >> m; //muestra la longitud de un contenedor
                //error si no existe la matricula

                cout << "#longitud " << m << endl;
                if (t.existe_contenedor(m))
                {
                    cout << t.longi_contenedor(m) << endl; 
                    //busca en el map el contenedor, imprime su longitud
                }

                else cout << "error: el contenedor no existe" << endl;
            }

            else if (comando == "contenedor_ocupa") //dificil
            {
                int i, j, k; //posicion en el map
                cin >> i >> j >> k;

                cout << "#contenedor_ocupa " << i << " " << j << " " << k << endl;

                //devuelve la matricula del contenedor situado en esa posicion
                //error si hay un hueco en esa posicion o esta fuera de los limites
                if ((i >= t.filas_al() or j >= t.plazas_al() or k >= t.pisos_al()) or (i < 0 or j < 0 or k < 0))
                {
                    cout << "error: ubicacion fuera de rango" << endl;
                }
                else cout << t.contenedor_ocupa(i, j, k) << endl; //retorna string o nada si hay un hueco
            }

            else if (comando == "num_hileras") 
            {
                cout << "#num_hileras" << endl;
                //imprime el numero de hileras de la terminal
                cout << t.filas_al() << endl;
            }

            else if (comando == "num_plazas") 
            {
                cout << "#num_plazas" << endl;
                //imprime el numero de plazas de la terminal
                cout << t.plazas_al() << endl;
            }

            else if (comando == "num_pisos") 
            {
                cout << "#num_pisos" << endl;
                //imprime el numero de pisos de la terminal
                cout << t.pisos_al() << endl;
            }

            else if (comando == "area_espera") 
            {
            //imprimir el area de espera
            cout << "#area_espera" << endl;
            t.imprimir_area_espera();
            }
            
            else if (comando == "contenedores") 
            {
                cout << "#contenedores" << endl;
                //imprimir los contenedores del conjunto en comando de matricula, con su ubicacion y su longitud
                t.imprimir_contenedores();
            }

            else if (comando == "area_almacenaje")
            {
                cout << "#area_almacenaje" << endl;
                //imprime el area de almacenaje por hileras, imprimiendo tambien los contenedores de cada hilera
                //las hileras con M > 9 se vuelven a repetir desde el 0
                t.imprimir_area_almacenaje();
            }

            else if (comando == "huecos")
            {
                cout << "#huecos" << endl;
                //imprime los huecos de la terminal, primero su ubicacion y luego la longitud del hueco
                t.imprimir_huecos();
            }
            cin >> comando;
        }
    }
}
