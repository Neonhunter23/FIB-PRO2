var searchData=
[
  ['u_217',['u',['../class_segmento.html#a7fab9490df9b1b655bb88c2deb6e72ef',1,'Segmento']]]
];
