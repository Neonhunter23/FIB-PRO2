var searchData=
[
  ['segmento_113',['Segmento',['../class_segmento.html',1,'']]]
];
