var searchData=
[
  ['d_28',['d',['../class_terminal.html#a214c95f8f43627f9082317c0c8f0a67c',1,'Terminal']]],
  ['documentació_20de_20la_20pràctica_3a_20gestió_20d_27una_20terminal_20de_20contenidors_29',['Documentació de la pràctica: Gestió d&apos;una terminal de contenidors',['../index.html',1,'']]]
];
