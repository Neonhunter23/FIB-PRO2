var searchData=
[
  ['documentació_20de_20la_20pràctica_3a_20gestió_20d_27una_20terminal_20de_20contenidors_223',['Documentació de la pràctica: Gestió d&apos;una terminal de contenidors',['../index.html',1,'']]]
];
