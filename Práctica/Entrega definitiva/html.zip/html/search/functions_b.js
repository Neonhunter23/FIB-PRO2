var searchData=
[
  ['segmento_189',['Segmento',['../class_segmento.html#af8ce1463824db8cd38084f4f75d3b192',1,'Segmento::Segmento()'],['../class_segmento.html#a325e58fb03daa6d14ceeb3c4759b042d',1,'Segmento::Segmento(const Ubicacion &amp;u, int l)'],['../class_segmento.html#a18576aa0c0d5d4200e23b84d760b5aa3',1,'Segmento::Segmento(const Segmento &amp;s)']]]
];
