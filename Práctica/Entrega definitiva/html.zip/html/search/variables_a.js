var searchData=
[
  ['x_218',['x',['../class_ubicacion.html#aa025967df0ca8761587b09a38cf5b798',1,'Ubicacion']]]
];
