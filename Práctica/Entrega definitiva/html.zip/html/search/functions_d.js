var searchData=
[
  ['ubi_5fbuena_191',['ubi_buena',['../class_cjt___huecos.html#a04dc20c954207d65559aaad5b6fa3c7d',1,'Cjt_Huecos']]],
  ['ubic_192',['ubic',['../class_segmento.html#aeb7bfd4dcac3a1a000a33582861e0d50',1,'Segmento']]],
  ['ubicacion_193',['Ubicacion',['../class_ubicacion.html#a9014ea9ce9297b951a07a668a5fb7cc4',1,'Ubicacion::Ubicacion()'],['../class_ubicacion.html#a423ae49933ff18f187e1f034d295f4c1',1,'Ubicacion::Ubicacion(int i, int j, int k)'],['../class_ubicacion.html#abbd148f34df6cde35f0f3803c8a98660',1,'Ubicacion::Ubicacion(const Ubicacion &amp;u)']]]
];
