var searchData=
[
  ['terminal_190',['Terminal',['../class_terminal.html#aa448509b5aa1ece53c3d86385655be0e',1,'Terminal::Terminal()'],['../class_terminal.html#a696ee89f0fc7359b528c9f8f2aec064f',1,'Terminal::Terminal(int N, int M, int H)']]]
];
